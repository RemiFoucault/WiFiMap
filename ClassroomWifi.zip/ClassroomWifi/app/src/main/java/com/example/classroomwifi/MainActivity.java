package com.example.classroomwifi;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.LocationManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;

import com.karan.churi.PermissionManager.PermissionManager;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public TextView dial;
    public EditText editColumn, editRow;
    public Button buttonStart;
    public Button buttonStop;

    public String startStr = "START";
    public String stopStr = "STOP";

    public boolean scanningState = false;
    public boolean writeResults = false;
    public boolean getScanTime = false;
    public long scanTime;

    public PermissionManager permission;
    public ArrayList<String> granted;
    public ArrayList<String> denied;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);

        dial = findViewById(R.id.dial);
        editColumn = findViewById(R.id.editColumn);
        editRow = findViewById(R.id.editRow);
        buttonStart = findViewById(R.id.buttonStart);
        buttonStop = findViewById(R.id.buttonStop);

        buttonStart.setText(startStr);
        buttonStart.setEnabled(true);
        buttonStop.setText(stopStr);
        buttonStop.setEnabled(false);

        permission = new PermissionManager() {};
        permission.checkAndRequestPermissions(this);

        measurementInit();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,String[] permissions, int[] grantResults) {
        permission.checkResult(requestCode,permissions, grantResults);
        granted = permission.getStatus().get(0).granted;
        denied = permission.getStatus().get(0).denied;
    }

    public void measurementInit() {
        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        wifiManager.setWifiEnabled(true);

        //Setting the BroadcastReceiver for the measurements
        BroadcastReceiver wifiScanReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent intent) {
                if(getScanTime){
                    //if we are in the preliminary measurement of the scanTime
                    scanTime = System.currentTimeMillis() - scanTime;
                    getScanTime = false;
                }
                if(writeResults){
                    //If we are in the actual measurement loop

                    //Writing the measurements in the csv file
                    writeResults = false;
                    WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    List<ScanResult> wifiList = wifiManager.getScanResults();
                    String header = "date," + System.currentTimeMillis() + ",size," + wifiList.size() + "/";
                    try {
                        FileOutputStream dataFile = openFileOutput("dataFile.csv", MODE_APPEND);
                        dataFile.write(header.getBytes());
                        for (ScanResult scanResult : wifiList) {
                            String s = scanResult.SSID + "," + scanResult.BSSID + "," + scanResult.frequency + "," + scanResult.level + "/";
                            dataFile.write(s.getBytes());
                        }
                        dataFile.close();
                    } catch(FileNotFoundException e){
                        dial.append("measurementInit1 caught FileNotFoundException :\n");
                        dial.append(e.getMessage() + "\n");
                    } catch(IOException e){
                        dial.append("measurementInit1 caught IOException :\n");
                        dial.append(e.getMessage() + "\n");
                    }
                }
            }
        };
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        getApplicationContext().registerReceiver(wifiScanReceiver, intentFilter);
    }


    @Override
    protected void onDestroy(){
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        super.onDestroy();
    }


    public int clickButtonStart(View view) {

        boolean res = locationEnabled(getApplicationContext());
        if(!res) {
            dial.setText("Please turn on your location and then press START again\n");
            return -1;
        }

        buttonStart.setEnabled(false);
        buttonStop.setEnabled(true);
        editColumn.setEnabled(false);
        editRow.setEnabled(false);

        //Writing the position in the csv file
        String s = "Column," + editColumn.getText() + ",Row," + editRow.getText() + "/";
        try {
            FileOutputStream dataFile = openFileOutput("dataFile.csv", MODE_APPEND);
            dataFile.write(s.getBytes());
            dataFile.close();
        } catch(FileNotFoundException e){
            dial.append("clickButtonStart1 caught FileNotFoundException :\n");
            dial.append(e.getMessage() + "\n");
        } catch(IOException e){
            dial.append("clickButtonStart1 caught IOException :\n");
            dial.append(e.getMessage() + "\n");
        }

        dial.setText("Starting measurements, press STOP to finish\n");

        //Launching one scan to determine scanTime
        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        boolean success = false;
        scanTime = System.currentTimeMillis();
        try {
            success = wifiManager.startScan();
            getScanTime = true;
        } catch(SecurityException e) {
            dial.append("clickButtonStart scanTime caught SecurityException :\n");
            dial.append(e.getMessage() + "\n");
        }
        if (!success) {
            dial.append("scanTime startScan launch failed\n");
        }


        Thread threadWait = new Thread() {
            @Override
            public void run() {
                try {
                    //wait 5 seconds to let the app teh time to determine scanTime (the code above)
                    sleep(5000);

                    //wait for synchronisation
                    long currentTime = System.currentTimeMillis();
                    while ((currentTime / 10) % (3200-(scanTime/10)) != 0) {
                        sleep(10);
                        currentTime = System.currentTimeMillis();
                    }
                    scanningState = true;

                    //Launching cyclic measurements
                    Thread threadScan = new Thread() {
                        @Override
                        public void run() {
                            try {
                                while(scanningState) {
                                    WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                                    boolean successLaunch = false;
                                    try {
                                        successLaunch = wifiManager.startScan();
                                    } catch(SecurityException e) {
                                        dial.append("clickButtonStart threadScan caught SecurityException :\n");
                                        dial.append(e.getMessage() + "\n");
                                    }
                                    if (!successLaunch) {
                                        dial.append("startScan launch failed\n");
                                    }
                                    writeResults = true;
                                    sleep(32000);
                                }
                            } catch (InterruptedException e) {
                                dial.append("clickButtonStart threadScan caught InterruptedException :\n");
                                dial.append(e.getMessage() + "\n");
                            }
                        }
                    };
                    threadScan.start();

                }
                catch(InterruptedException e){
                    dial.append("clickButtonStart threadWait caught InterruptedException :\n");
                    dial.append(e.getMessage() + "\n");
                }
            }
        };
        threadWait.start();
        return 0;
    }

    public boolean locationEnabled(Context context) {
        try {
            LocationManager lm =(LocationManager) context.getApplicationContext().getSystemService(Activity.LOCATION_SERVICE);
            List<String> locationProviders = lm.getProviders(true);
            return (locationProviders.size() > 1);
        } catch (Exception e) {
            dial.append("locationEnabled caught Exception :\n");
            dial.append(e.getMessage() + "\n");
        }
        return(false);
    }

    public void clickButtonStop(View view){
        scanningState = false;
        dial.append("Done\n");
        dial.append("Starting to upload the data, please wait ...\n");

        new AsyncDataUpload().execute();

        editColumn.setEnabled(true);
        editRow.setEnabled(true);
        buttonStart.setEnabled(true);
        buttonStop.setEnabled(false);
    }


    public class AsyncDataUpload extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... params) {
            try {
                //Connecting to a web server
                URL url = new URL("Your_Web_Server");
                HttpURLConnection httpUrlConnection = (HttpURLConnection) url.openConnection();

                try {
                    //Sending the content of the csv file to the web server
                    httpUrlConnection.setRequestMethod("POST");
                    httpUrlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    httpUrlConnection.setRequestProperty("Accept-Charset", "UTF-8");
                    OutputStream requestStream = new BufferedOutputStream(httpUrlConnection.getOutputStream());
                    BufferedWriter requestStreamWriter = new BufferedWriter(new OutputStreamWriter(requestStream));

                    FileInputStream dataFile = getApplicationContext().openFileInput("dataFile.csv");
                    int value;
                    StringBuilder lu = new StringBuilder();
                    while ((value = dataFile.read()) != -1) {
                        lu.append((char) value);
                    }
                    requestStreamWriter.write(lu.toString());
                    requestStreamWriter.flush();
                    requestStreamWriter.close();
                    requestStream.close();

                    InputStream responseStream = new BufferedInputStream(httpUrlConnection.getInputStream());
                    BufferedReader responseStreamReader = new BufferedReader(new InputStreamReader(responseStream));
                    String line;
                    StringBuilder stringBuilder = new StringBuilder();
                    while ((line = responseStreamReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    responseStreamReader.close();
                    responseStream.close();
                } catch (FileNotFoundException e) {
                    dial.append("AsyncDataUpload caught FileNotFoundException :\n");
                    dial.append(e.getMessage() + "\n");
                } catch (IOException e) {
                    dial.append("AsyncDataUpload caught IOException :\n");
                    dial.append(e.getMessage() + "\n");
                } finally {
                    httpUrlConnection.disconnect();
                    dial.append("Done\n");
                    File myFile = new File(getApplicationContext().getFilesDir().getAbsolutePath() + File.separator + "dataFile.csv");
                    boolean res = myFile.delete();
                    if (!res) {
                        dial.append("Error while deleting data file\n");
                    }
                    dial.append("You can exit the application or start a new measurement session by pressing START\n\n");
                }

            } catch (MalformedURLException e) {
                dial.append("AsyncDataUpload caught MalformedURLException :\n");
                dial.append(e.getMessage() + "\n");
            } catch (IOException e) {
                dial.append("AsyncDataUpload caught IOException :\n");
                dial.append(e.getMessage() + "\n");
            }
            return null;
        }
    }
}
